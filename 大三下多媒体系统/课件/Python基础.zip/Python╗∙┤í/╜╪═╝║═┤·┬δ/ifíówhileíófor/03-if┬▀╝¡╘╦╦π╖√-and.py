you = input("你去么?") # 去或者不去
yourWife = input("你老婆去么?") #去或者不去

#if you=="去" 并且 yourWife=="去":
if you=="去" and yourWife=="去":
    print("可以成功的办好某件事情....")
