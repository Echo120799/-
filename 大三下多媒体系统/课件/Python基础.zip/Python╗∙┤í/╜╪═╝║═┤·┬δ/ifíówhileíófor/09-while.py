i = 1

while i<=100:
    print("%d"%i)#print(i)
    i = i+1


'''

i=1
while xxxx:
    xxxx22llsdjkfksdjf
    ...
    i=i+1

'''
