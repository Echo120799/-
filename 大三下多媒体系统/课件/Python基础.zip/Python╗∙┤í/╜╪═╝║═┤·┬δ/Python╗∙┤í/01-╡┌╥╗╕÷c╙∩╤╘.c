#include<stdio.h>
int main(int argc,char ** argv)
{
    printf("hello haha\n");
    return 0;        
}
