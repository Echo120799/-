a = [11,22,33]
b = [44,55]

#a.extend(b)
a.append(b)

print(a)
