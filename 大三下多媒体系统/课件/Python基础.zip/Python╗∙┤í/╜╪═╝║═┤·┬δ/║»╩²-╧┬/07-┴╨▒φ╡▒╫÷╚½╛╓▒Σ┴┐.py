nums = [11,22,33]
infor = {"name":"laowang"}

def test():
    #for num in nums:
    #    print(num)

    nums.append(44)
    infor['age'] = 18

def test2():
    print(nums)
    print(infor)

test()
test2()
