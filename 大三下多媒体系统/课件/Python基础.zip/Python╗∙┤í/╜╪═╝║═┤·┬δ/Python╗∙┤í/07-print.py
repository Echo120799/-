print("hello world")

age = 18
print("age变量里的值是%d"%age)

name = "东哥"
print("名字是:%s"%name)
