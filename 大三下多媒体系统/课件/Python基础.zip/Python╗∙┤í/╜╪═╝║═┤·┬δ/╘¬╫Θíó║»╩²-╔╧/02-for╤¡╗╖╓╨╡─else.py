nums = [11,22,33,44]
#nums = []

for temp in nums:
    print(temp)
    break
else:
    print("=========")
