#1. 获取用户的输入
num = int(input("请输入一个数字(1~7):"))

#2. 判断用户的数据,并且显示对应的信息
if num==1:
    print("星期1")
elif num==2:
    print("星期2")
elif num==3:
    print("星期3")
elif num==4:
    print("星期4")
elif num==5:
    print("星期5")
elif num==6:
    print("星期6")
elif num==7:
    print("星期7")
else:
    print("你输入的数据有误....")
