from django.apps import AppConfig


class CustomUserConfig(AppConfig):
    name = 'custom_user'
    verbose_name = '用户信息'
