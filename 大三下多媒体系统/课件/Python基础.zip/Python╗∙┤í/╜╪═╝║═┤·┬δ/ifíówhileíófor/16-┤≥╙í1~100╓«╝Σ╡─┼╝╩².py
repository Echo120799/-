i = 1
while i<=100:
    #if i是个偶数:
    if i%2==0:
        print(i)
    i+=1
