#-*- coding:utf-8 -*-



'''#coding=utf-8'''

#以下代码用来打印一个信息
print("hello world")


#当行注释
#这里是单行注释,zxxksjdkfjs
#djfjksdfsdjflsdjflskjdflsad
# 井号是一个单行注释,提醒的内容不能换行,如果换了行,那么,需要在新的一行的
# 行首添加一个#

#多行注释
'''
print("hello world")
print("hello world")
print("hello world")
print("hello world")
'''

"""
print("hello world")
print("hello world")
"""
