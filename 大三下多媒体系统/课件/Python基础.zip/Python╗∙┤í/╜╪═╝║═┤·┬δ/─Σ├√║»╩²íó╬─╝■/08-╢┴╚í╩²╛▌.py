f = open("xxx.txt","r")

content = f.read()
print(content)

f.close()
