def print_menu():
    print("="*50)
    print("   名片管理系统通v0.1")
    print(" 1:xxx")
    print(" 2:xxx")
    print("="*50)

def print_sanjiaoxing():
    print("*")
    print("*"*2)
    print("*"*3)
    print("*"*4)

print_menu()
print_sanjiaoxing()
