sex = input("请输入你的性别:")

if sex == "男":
    print("你是男性,可以留胡子....")
elif sex == "女":
    print("你是女性,可以留长头发....")
#elif sex == "中性":
else:
    print("你是第3中 性别,想干啥就干啥.....")
