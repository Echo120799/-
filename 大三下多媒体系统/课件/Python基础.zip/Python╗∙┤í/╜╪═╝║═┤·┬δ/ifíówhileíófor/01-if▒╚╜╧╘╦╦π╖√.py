age = 19
#if age大于或者等于18:
if age >= 18:
    print("成年.可以去网吧....")


