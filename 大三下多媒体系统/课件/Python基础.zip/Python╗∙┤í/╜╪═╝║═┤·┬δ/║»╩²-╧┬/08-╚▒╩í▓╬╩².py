def test(a,d,b=22,c=33):
    print(a)
    print(b)
    print(c)
    print(d)

test(d=11,a=22,c=44)
