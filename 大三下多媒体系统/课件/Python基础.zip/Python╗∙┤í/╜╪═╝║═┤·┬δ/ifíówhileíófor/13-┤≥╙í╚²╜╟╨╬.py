i = 1

while i<=5:

    '''
    #从键盘中输入一个值,这个值用来控制这行中*的个数
    num = int(input("请输入这个行里的*的个数:"))
    
    j = 1
    while j<=num:
        print("*", end="")
        j+=1
    '''
    j = 1
    while j<=i:
        print("*", end="")
        j+=1

    print("")

    i+=1
